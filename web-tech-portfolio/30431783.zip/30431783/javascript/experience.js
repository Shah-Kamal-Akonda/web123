document.addEventListener('DOMContentLoaded', function() {
    const skillSelect = document.getElementById('skills');
    const skillDescriptions = document.querySelectorAll('.skill-description > div');

    skillSelect.addEventListener('change', function() {
        const selectedSkill = this.value;

        skillDescriptions.forEach(function(description) {
            if (description.classList.contains(selectedSkill)) {
                description.style.display = 'block';
            } else {
                description.style.display = 'none';
            }
        });
    });

    // Trigger change event to show the first skill by default
    skillSelect.dispatchEvent(new Event('change'));
});
