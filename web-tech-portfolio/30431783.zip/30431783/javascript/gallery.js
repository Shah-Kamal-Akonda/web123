document.addEventListener('DOMContentLoaded', function() {
    const images = [
        { src: '../images/project-image-1.jpg', description: 'I developed a personal cloud storage system using Raspberry Pi and NextCloud. This project involved setting up a private cloud server to manage and store data securely. The Raspberry Pi acted as the server, providing an efficient and cost-effective solution for personal cloud storage.This experience allowed me to understand the intricacies of cloud server setup, data management, and secure storage solutions. ' },


        { src: '../images/project-image-2.jpg', description: 'I created an AI-powered chatbot designed to improve customer service interactions on e-commerce websites. The chatbot was developed using cloud-based AI tools and integrated with a cloud database to store and retrieve user queries and responses. This project not only enhanced my programming skills but also provided me with valuable experience in using cloud services for AI development and deployment. The chatbot was able to handle multiple queries simultaneously, providing real-time responses and improving overall customer satisfaction.' },


        { src: '../images/project-image-3.jpg', description: 'I worked on an online blood bank system that leverages cloud computing to maintain a centralized database of blood donors and availability. The cloud-based application stores detailed information about blood types, donors, and storage locations, facilitating quick access to blood during emergencies. This project taught me about cloud database management, scalability, and the importance of reliable and secure data storage. It also highlighted the potential of cloud computing in healthcare, improving the efficiency and accessibility of critical resources.' },

        { src: '../images/project-image-4.jpg', description: 'I implemented a cloud-based smart traffic management system designed to optimize traffic flow in urban areas. This project utilized cloud computing to collect and analyze real-time traffic data from various sensors and cameras installed across the city. The system employed machine learning algorithms to predict traffic congestion and dynamically adjust traffic signals to improve traffic flow. This project demonstrated my ability to integrate IoT devices with cloud computing and utilize data analytics to solve real-world problems.' },

        { src: '../images/project-image-5.jpg', description: 'I developed an automated university portal that streamlines various administrative tasks such as student registration, exam scheduling, and result publication. This cloud-based portal provided separate login portals for students, faculty, and administrative staff, ensuring secure access and management of data. The project involved setting up a robust cloud infrastructure, integrating database management systems, and ensuring data security and compliance. This experience enhanced my skills in cloud service management and full-stack development.' },

        { src: '../images/project-image-6.jpg', description: 'I created a cloud-based healthcare management system to improve the efficiency of medical records management and patient care. The system allowed healthcare providers to store, retrieve, and update patient records securely from any location. It also integrated with various medical devices to monitor patient vitals in real-time and alert healthcare professionals in case of emergencies. This project emphasized the importance of data security and compliance with healthcare regulations, showcasing my ability to develop secure and scalable cloud solutions.' }

    ];

    let currentIndex = 0;

    const sliderImage = document.getElementById('slider-image');
    const descriptionContent = document.querySelector('.img-description-content');
    const nextArrow = document.getElementById('next-arrow');

    nextArrow.addEventListener('click', function() {
        currentIndex = (currentIndex + 1) % images.length;
        sliderImage.src = images[currentIndex].src;
        descriptionContent.textContent = images[currentIndex].description;
    });
});